package notebook.view;

import notebook.controller.UserController;
import notebook.model.User;
import notebook.model.repository.GBRepository;
import notebook.util.Commands;

public class UserView extends UserController {
    private final UserController repository;
    public UserView(UserController userController) {
        this(repository, userController);
    }

    public void run(){
        Commands com;

        while (true) {
            String command = prompt("Введите команду: ");
            com = Commands.valueOf(command);
            if (com == Commands.EXIT) return;
            switch (com) {
                case CREATE:
                    User u = createUser();
                    UserController userController;
                    userController.saveUser(u);
                    break;
                case DELETE: // Новое по домашке
                    String userId = prompt("Enter user id: ");
                    userController.removeUser(userId, removeUser());
                    //вызвать ремув юзера и записать обратно список
                case READ:
                    String id = prompt("Идентификатор пользователя: ");
                    try {
                        User user = userController.readUser(Long.parseLong(id));
                        System.out.println(user);
                        System.out.println();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    break;
                case LIST:
                    System.out.println(userController.readAll());
                case UPDATE:
                    String userId = prompt("Enter user id: ");
                    userController.updateUser(userId, createUser());
            }
        }
    }



}
