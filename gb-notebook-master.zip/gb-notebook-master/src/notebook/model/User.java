package notebook.model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class User {
    private Long id;
    private String firstName;
    private String lastName;
    private String phone;

    public User(String firstName, String lastName, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
    }

    public User(Long id, String firstName, String lastName, String phone) {
        this(firstName, lastName, phone);
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return String.format("Идентафикатор: %s\nИмя: %s,\nФамилия: %s,\nТелефон: %s", id, firstName, lastName, phone);
    }

    public static class FileOperation implements Operation {
        private final String fileName;

        public FileOperation(String fileName) {
            this.fileName = fileName;
            try (FileWriter writer = new FileWriter(fileName, true)) {
                writer.flush();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }

        @Override
        public List<String> readAll() {
            List<String> lines = new ArrayList<>();
            try {
                File file = new File(fileName);
                //создаем объект FileReader для объекта File
                FileReader fr = new FileReader(file);
                //создаем BufferedReader с существующего FileReader для построчного считывания
                BufferedReader reader = new BufferedReader(fr);
                // считаем сначала первую строку
                String line = reader.readLine();
                if (line != null) {
                    lines.add(line);
                }
                while (line != null) {
                    // считываем остальные строки в цикле
                    line = reader.readLine();
                    if (line != null) {
                        lines.add(line);
                    }
                }
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return lines;
        }

        @Override
        public void saveAll(List<String> data) {
            try (FileWriter writer = new FileWriter(fileName, false)) {
                for (String line : data) {
                    // запись всей строки
                    writer.write(line);
                    // запись по символам
                    writer.append('\n');
                }
                writer.flush();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    /**
     * Data Access Object (DAO) слой, с методами для работы с БД
     */
    public static interface Operation {
        List<String> readAll();
        void saveAll(List<String> data);
    }
}
